"use client";

import type { DashboardUser, ViewKey } from "../types";
import { navItems } from "../data/navigation";

type DashboardSidebarProps = {
  activeView: ViewKey;
  allowedViews: ViewKey[];
  user: DashboardUser;
  profileStatus: "متصل" | "غير متصل";
  onChangeView: (view: ViewKey) => void;
  onOpenProfile: () => void;
};

function getInitial(name: string) {
  return name.trim().charAt(0) || "ع";
}

export default function DashboardSidebar({
  activeView,
  allowedViews,
  user,
  profileStatus,
  onChangeView,
  onOpenProfile
}: DashboardSidebarProps) {
  const visibleNavItems = navItems.filter((item) => allowedViews.includes(item.key));

  return (
    <aside className="dashboard-sidebar">
      <div className="brand">
        <span className="brand-mark">
          <img src="/assets/audiencew-logo.png" alt="" />
        </span>
        AudienceW
      </div>
      <div className="tenant-card">
        <b>حساب العميل</b>
        <span>لم يتم تحديد الباقة</span>
      </div>
      <nav className="dashboard-nav">
        {visibleNavItems.map((item) => (
          <button
            className={activeView === item.key ? "active" : ""}
            key={item.key}
            type="button"
            onClick={() => onChangeView(item.key)}
          >
            {item.label}
          </button>
        ))}
      </nav>
      <div className="sidebar-footer">
        <b>حالة الربط</b>
        <span>لم يتم ربط WhatsApp Cloud API بعد.</span>
      </div>
      <button className="account-btn" type="button" onClick={onOpenProfile}>
        <span className="account-avatar">{getInitial(user.name)}</span>
        <span>
          <b>{user.name}</b>
          <small>{user.role}</small>
          <em className={profileStatus === "متصل" ? "online" : "offline"}>{profileStatus}</em>
        </span>
      </button>
    </aside>
  );
}
